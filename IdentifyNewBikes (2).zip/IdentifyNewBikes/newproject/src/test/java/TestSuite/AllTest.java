package TestSuite;

import java.io.IOException;

 

import org.testng.annotations.Test;

 

import com.aventstack.extentreports.Status;

 

import Base.Base;
import Pages.ChennaiUsedCars;
import Pages.HondaDetails;
import Pages.LoginPage;

public class AllTest extends Base{
    HondaDetails hd= new HondaDetails(); 
    ChennaiUsedCars cu = new ChennaiUsedCars();
    LoginPage l= new LoginPage();

    @Test(groups="smoke", priority = 1)
    public void InvokeBrowser()throws InterruptedException, IOException {
        logger = report.createTest("Opening Browser");
        logger.log(Status.PASS, "Invoking Browser");
        hd.openUrl();

    }

    @Test(groups="smoke", priority = 2)
    public void ClosePopup()throws InterruptedException, IOException {
        logger = report.createTest("Popup Closed");
        logger.log(Status.PASS, "Closing Popup");
        hd.closeLoginPopUp();

    }

    @Test (groups="smoke", priority = 3)
    public void UpcomingBikes() throws InterruptedException, IOException{

        hd.clickUpcomingBikes();
    }

    @Test(groups="smoke", priority = 4)
    public void Manufacturer() throws InterruptedException, IOException{
        hd.selectManufacturer();
    }

    @Test(groups="smoke", priority = 5)
    public void ViewMore() throws InterruptedException, IOException{
        hd.viewMore();
    }


    @Test(groups="smoke", priority = 6)
    public void BikePrices() throws InterruptedException, IOException{
        hd.printDetails();
    }


    @Test(groups="regression", priority = 7)
    public void OpenURL()throws InterruptedException, IOException {
        logger = report.createTest("Opening URL");
        logger.log(Status.PASS, "Opening Browser");
        hd.openUrl();

    }
    @Test(groups="regression", priority = 8)
    public void UsedCars()throws InterruptedException, IOException {
        cu.clickUsedCars();
    }

    @Test(groups="regression", priority = 9)
    public void PopularModels()throws InterruptedException, IOException {
        cu.clickPopularModels();
    }

    @Test(groups="regression", priority = 10)
    public void OpenloginURL()throws InterruptedException, IOException {
        logger = report.createTest("Opening URL");
        logger.log(Status.PASS, "Opening Browser");
        l.openUrl(); 
    }

    @Test(groups="regression", priority = 11)
    public void Login()throws InterruptedException, IOException {
        l.clickLogin();
    }

    @Test(groups="regression", priority = 12)
    public void GoogleSignIn()throws InterruptedException, IOException {
        l.clickGoogleSignIn();
    }

    @Test(groups="regression", priority = 13)
    public void ErrorMessage()throws InterruptedException, IOException {
        l.captureErrorMessage();
    }

    @Test(groups="regression", priority = 14)
    public void CloseBrowser()throws InterruptedException, IOException {
        hd.closeBrowser();
    }

}

