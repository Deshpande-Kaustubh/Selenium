package Pages;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import Base.Base;
import utils.WriteDataExcel;

public class HondaDetails extends Base {
    //Excel filepath
    String path = "C:\\Users\\2282487\\Downloads\\IdentifyNewBikes\\newproject\\src\\test\\resources\\IdentifyNewBikes.xlsx";
    WriteDataExcel data = new WriteDataExcel(path);

    By newbikes = By.xpath("//a[normalize-space()='New Bikes']");
    By upcomingbikes = By.xpath("//span[@onclick=\"goToUrl('/upcoming-bikes')\"]");
    By smanuf = By.xpath("//select[@id='makeId']");
    By loginclose = By.id("alternate-login-close");
    By viewButton = By.xpath("//span[@class='zw-cmn-loadMore']");
    By BikeNames = By.xpath("//strong[@class='lnk-hvr block of-hid h-height']");
    By BikePrices = By.xpath("//div[@class='b fnt-15']");
    By BikeLaunch = By.xpath("//div[@class='clr-try fnt-14']");
    By scroll = By.id("carGarage");
    int count = 0, count1 = 0;

    public void clickUpcomingBikes() // Method to click Upcoming_bikes
    {
        logger = report.createTest("Upcoming Bikes");
        try
        {
            WebElement w1 = driver.findElement(newbikes);

            Actions act = new Actions(driver);
            act.moveToElement(w1).perform();

            WebElement a = driver.findElement(upcomingbikes);
            highLighterMethod(driver, a );
                    a.click();

            String str= driver.findElement(By.xpath("//*[@id=\"headerNewNavWrap\"]/nav/div/ul/li[3]/ul/li[5]/span")).getText();

            if (str.contains("Upcoming Bikes"))
                reportPass("Upcoming bikes has been opened");
                } 
            catch (Exception e) 
                {
            reportFail(e.getMessage());
         }
     }

    public void selectManufacturer() // Method to select the Manufacturer
      {
        logger = report.createTest("Honda Manufacturer");
        try 
          {
            WebElement drop = driver.findElement(smanuf);
            Select select = new Select(drop);
            select.selectByValue("53");
            String str1 = driver.findElement(By.xpath("//span[@class=\"bc-cl\" and text()=\"Honda Bikes\"]")).getText();
            if (str1.contains("Honda Bikes"))
                reportPass("Manufacturer is HONDA");
           }
        catch (Exception e)
           {
            reportFail(e.getMessage());
           }
       }

    public void closeLoginPopUp() // Method to close the login-popup
       {
        WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(15));
        wait.until(ExpectedConditions.visibilityOfElementLocated(loginclose));
        driver.findElement(loginclose).click();
       }

    public void viewMore() // Method to click view more
      {
        logger = report.createTest("Accessing View More");
        try 
          {
           WebElement element = driver.findElement(viewButton);
           JavascriptExecutor executor = (JavascriptExecutor) driver;
           executor.executeScript("arguments[0].scrollIntoView(true);", element);
           Thread.sleep(1000);
           executor.executeScript("arguments[0].click();", element);
           reportPass("View More is clicked");
           WebElement scrollDown = driver.findElement(scroll);
           executor.executeScript("arguments[0].scrollIntoView(true);", scrollDown);
           } 
        catch (Exception e) 
          {
            reportFail(e.getMessage());
          }
       }

    public void printDetails() // Method to print details on the console
      {
        logger = report.createTest("Obtaining bike prices");
        List<WebElement> bikeNames = driver.findElements(BikeNames);
        List<WebElement> bikePrices = driver.findElements(BikePrices);
        List<WebElement> bikeLaunch = driver.findElements(BikeLaunch);
        count = bikeNames.size();
        String priceTxt;
        System.out.println("Upcoming Bike Details:");
        try 
         {
            data.setCellData("Upcoming Bikes", 0, 0,"Bike Names");
            data.setCellData("Upcoming Bikes", 0, 1,"Bike Price");
            data.setCellData("Upcoming Bikes", 0, 2,"Bike Launch Date");
            int k=0;
            for (int i = 0; i < count; i++)
              {
                priceTxt = bikePrices.get(i).getText();
                float price = Float.parseFloat(priceTxt.replaceAll("Rs. ", "").replaceAll(" Lakh", "").replaceAll(",", ""));
                if(price == 79000) 
                 {
                    price = price/100000;
                 }
                if (price < 4)
                 {
                	System.out.println(bikeNames.get(i).getText()+" "+bikePrices.get(i).getText()+" "+bikeLaunch.get(i).getText());
                    data.setCellData("Upcoming Bikes", k+1, 0,bikeNames.get(i).getText());
                    data.setCellData("Upcoming Bikes", k+1, 1,bikePrices.get(i).getText());
                    data.setCellData("Upcoming Bikes", k+1, 2,bikeLaunch.get(i).getText());
                    k++;
                  }
              }
            reportPass("Bike Prices are Obtained");
        }
        catch (Exception e) 
          {
            reportFail(e.getMessage());
            System.out.println(e.getMessage());
          }
       }
}





















