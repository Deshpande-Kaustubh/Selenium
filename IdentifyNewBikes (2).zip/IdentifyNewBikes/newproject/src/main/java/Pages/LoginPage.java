package Pages;

import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.openqa.selenium.By;

import Base.Base;
import org.openqa.selenium.WebElement;
import utils.WriteDataExcel;

public class LoginPage extends Base {
	
	String file="C:\\Users\\2282487\\Downloads\\IdentifyNewBikes\\newproject\\src\\test\\resources\\IdentifyNewBikes.xlsx";
	WriteDataExcel writeExcel = new WriteDataExcel(file);
	By lclose = By.id("alternate-login-close");
	By login = By.id("des_lIcon");
	By googleSignIn = By.xpath("//span[normalize-space()='Google']");
	By email = By.xpath("//input[@type='email']");
	By submit = By.xpath("//span[text()='Next']");

	By error = By.xpath("//div[@class='o6cuMc Jj6Lae']");

	public void clickLogin() // Method to click Login
	{
		logger = report.createTest("Displaying used car");
		try {
			WebElement d = driver.findElement(login);
			highLighterMethod(driver,d );
					d.click();
			Thread.sleep(5000);
			String login1 = "Login/Register to";
			String ver = driver.findElement(By.xpath("//*[contains(text(),\"Login/Register\")]")).getText();
			if (ver.contains(login1))
				reportPass("Login button Clicked");
		} catch (Exception e) {
			reportFail(e.getMessage());
		}
	}

	public void clickGoogleSignIn() throws InterruptedException // Method to click Login
, IOException
	{
		logger = report.createTest("Error Checking after signup");
		WebElement c = driver.findElement(googleSignIn);
		highLighterMethod(driver, c );
				c.click();
		for (String window : driver.getWindowHandles()) {
			driver.switchTo().window(window);
		}
//		driver.get("https://accounts.google.com/v3/signin/identifier?opparams=%253Fenable_serial_consent%253Dtrue&dsh=S621081056%3A1685612657568554&client_id=591154493254.apps.googleusercontent.com&gsiwebsdk=3&include_granted_scopes=true&o2v=2&prompt=select_account&redirect_uri=storagerelay%3A%2F%2Fhttps%2Fwww.zigwheels.com%3Fid%3Dauth44310&response_type=token&scope=https%3A%2F%2Fwww.googleapis.com%2Fauth%2Fuserinfo.profile++https%3A%2F%2Fwww.googleapis.com%2Fauth%2Fuserinfo.email&service=lso&flowName=GeneralOAuthFlow&continue=https%3A%2F%2Faccounts.google.com%2Fsignin%2Foauth%2Fconsent%3Fauthuser%3Dunknown%26part%3DAJi8hAMTSnud0nUoz06hOAl0A_kSwgDps6VdmqehHwqSjRJPKiWaBN--J5N7oscMQJSm0m5GHN6oHYH-0fIB4Kqc4aWgThgveE1Cd9N4NqHkWvI2pxkeApwagwx3_TF7Gu6iwrqxRnvTQIKIpq8v6Z8pPDadhFuAF-7S3vLRXrCa12E4O6nvqtZVEBIxK6ClbNBzbNiKQOPnMn8-cTh7J3whYkWEr_0QjF-wyPM20YfrGwav4XTnHvt2LaU536b-ZLZ6qh_1LmvhgbEKFjA9aiXGG0Z7eXTmOsmClxBGEiM8y23ifXPfUynI_LE-yNkWGsGJjusKAJ3PrFR8NtHeY81o2Y8NfHg2r_G1SyiCiRFUnhLniJoBBgdPtO5fPXBQEEn0AGEiSQKIRcl25enao-e5fJwJ69s9bk7aetHoZheAU-gKrd3D25w%26as%3DS621081056%253A1685612657568554%26client_id%3D591154493254.apps.googleusercontent.com%23&app_domain=https%3A%2F%2Fwww.zigwheels.com&rart=ANgoxcdTU2Awkr_dPsm1sDUpworr4pgeK-5zeqe28hyQF_XwpJORscu9cx-gYmbZ0wukztere2_pLkRNKTTpuzkG8wPG2o7rKw");
//		driver.findElement(email).sendKeys("trfuvcm@gmail.");
		WebElement searchField = driver.findElement(email);
		FileInputStream file = new FileInputStream("C:\\Users\\2282487\\Downloads\\IdentifyNewBikes\\newproject\\Mail_Input.xlsx");
		Workbook workbook = WorkbookFactory.create(file);
		Sheet sheet = workbook.getSheet("Sheet1");
		String search = sheet.getRow(0).getCell(0).getStringCellValue();
		searchField.sendKeys(search);
		driver.findElement(submit).click();
		reportPass("Login button Clicked");
		Thread.sleep(2000);
		Screenshoot("error");
	}

	public void captureErrorMessage() throws IOException // Method to capture error message
	{
		writeExcel.setCellData("Error Message", 0, 0, "Error Message");
		System.out.println("Error Obtained during Signup:");
		String errorMessage = driver.findElement(error).getText();
		System.out.println(errorMessage);
		writeExcel.setCellData("Error Message", 1, 0, errorMessage);
		
	
	}
}
