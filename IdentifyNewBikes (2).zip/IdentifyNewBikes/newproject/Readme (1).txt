
Problem Statement : Identify New Bikes
Website           : "https://www.zigwheels.com/"
---------------------------------------------------------------------


1) Display upcoming bikes details like , bike name, its price and expected launch date in India
     * Manufacturer should be Honda.
     * Bike price should be less than 4Lac.

2) For Used cars in Chennai, extract all the popular models in a List.
     * Display the details of Used Cars.


3) Try to 'Login' with google, give invalid account details. 
     * Capture the error message.


Steps of the Procedure:
----------------------------------------------------------------------

1)  Launch any browser (In this code we have used Chrome browser and Microsoft Edge browser). 
2)  Goto “https://www.zigwheels.com/”. 
3)  Hover the mouse in the "New Bikes" and click on "Upcoming Bikes." (It will take user to ‘Upcoming Bikes’ page).
4)  Drag and drop the ‘Manufacturer’ slider to Honda.
5)  Click on the "View More Bikes"
6)  Display the bikes details like bike name, price and expected launch date in India for bikes less than '4 Lakhs.'
7)  Hover the mouse in the "Used Cars" and click on "Used Cars." (It will take user to ‘Used Cars’ page).
8)  Take the list of all the popular models under 'Popular Models' and print it on the console. 
9)  Scroll the page up and click on ‘Home’ Option. (It will take user to ‘Home’ page).
10) Click on the ‘Login/Signup’ option. (User will get a Pop up "Login/Register to ZigWheels").
11) Click on "Continue with Google."
12) Enter the invalid email in the "Email or phone" textbox.
13) Click ‘NEXT’ Button.
14) Check whether error message is displayed.
15) Display the error message on the console.
16) Capture the error message.
17) Navigate to "Home Page."


Folders
----------------------------------------------------------------------

1) src/main/java
       i)   HACKATHON
           -LaunchChrome.java
           -UpcomingBikes.java
           -ChennaiUsedCars.java
           -LoginPage.java
           -ExtentReports.java

3)src/test/java
            -SmokeTest.java

2) Drivers
   i)  chromedriver.exe
   ii) msedgedriver.exe

3) reports- (extent report saved here)
     
4) Screenshot



Data Driven Concepts
-----------------------------------------------------------------------
1) Properties File (Reading Data)

   * (Config.properties)- This properties file is present in        
   * This file conists of Browser name and URL value.




Key Automation Scope
-------------------------------------------------------------------------


-> Locating elements precisely.
-> Using appropriate synchronization technique.
-> Extracting menu items & store in collections
-> Scrolling up and down in web page
-> Filling form (in different objects in web page)
-> Capture warning message   
-> Taking Screenshots


Technology/Automation Tools Used
-------------------------------------------------------------------------
1) Selenium Webdriver and it's concepts.
2) Maven
3) TestNG framework and it's concepts.
4) Data Driven approach
5) Page Object Model
6) Extent Report/ TestNG Report
7) Excel and Property file concepts
8) Multiple Browser testing concepts
9) Java Concepts


                                  
                                  ----------------------------
                                  |                          |
                                  |      IMPORTANT NOTE      |
                                  |                          |
                                  ----------------------------

    -> For mutiple browsers (chrome and Edge), The brower name is read from 'Config.properties' file
    -> If you want to use chrome brower, please go to 'Config.properties' file and set browser name as 'chrome'.
    -> If you want to use edge brower, please go to 'Config.properties' file and set browser name as 'edge'.
    -> Then execute the Test.


 
     

   