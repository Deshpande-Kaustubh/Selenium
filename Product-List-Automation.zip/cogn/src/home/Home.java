package home;
//import home.Browser;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

import org.apache.commons.io.FileUtils;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.*;

import java.io.*;


public class Home {
    public static void main(String[] args) throws IOException {
        // Set the path to the chromedriver executable

//        System.setProperty("webdriver.chrome.driver", "C:/Users/2282531/Downloads/chromedriver_win32/chromedriver.exe");

        Browser br = new Browser();
        br.setDriver();
        // Launch Chrome browser
//        WebDriver driver = new ChromeDriver();
        br.driver.manage().window().maximize();

// For Extent HTML Report
        ExtentSparkReporter htmlReporter = new ExtentSparkReporter("C:\\Users\\2282531\\IdeaProjects\\cogn\\src\\home\\extent-report.html");
        ExtentReports extent = new ExtentReports();
        extent.attachReporter(htmlReporter);

        ExtentTest test = extent.createTest("Test Case - 1", "Sample Description");
        String title = br.driver.getTitle();
        test.log(Status.INFO, "Navigating to website");
        test.log(Status.INFO, "Website title is: " + title);

// Verify the title
        if (title.equals("Online Furniture Shopping Store: Shop Online in India for Furniture, Home Decor, Homeware Products @ Pepperfry")) {
            test.log(Status.PASS, "Title is correct");
        } else {
            test.log(Status.FAIL, "Title is incorrect");
        }

        // Validate the title of the webpage
        String pageTitle = br.driver.getTitle();
        if (pageTitle.contains("Online Furniture Shopping Store")) {
            System.out.println("Title validation passed");
        } else {
            System.out.println("Title validation failed");
        }


        // Select "Furniture" from the navigation menu
        WebElement furnitureMenu = br.driver.findElement(By.xpath("//a[contains(text(),'Furniture')]"));
        highLighterMethod(br.driver, furnitureMenu);
        furnitureMenu.click();

        ExtentTest test2 = extent.createTest("Test Case - 2", "Sample Description");
        test2.log(Status.INFO, "Navigating to the Furniture");
        String expectedUrl2="https://www.pepperfry.com/";
        String actualUrl2= br.driver.getCurrentUrl();

        if(expectedUrl2.equalsIgnoreCase(actualUrl2)) {
            test2.log(Status.PASS, "Successfully navigated to the Furniture");
        } else {
            test2.log(Status.FAIL, "Failed to navigate to the Furniture");
        }

        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
//        br.driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);

        // Click on "Benches" category
        WebElement benchesCategory = br.driver.findElement(By.xpath("//a[normalize-space()='Benches']"));
        highLighterMethod(br.driver, benchesCategory);
        benchesCategory.click();

        ExtentTest test3 = extent.createTest("Test Case - 3", "Sample Description");
        test3.log(Status.INFO, "Navigating to the Benches");
        String expectedUrl3="https://www.pepperfry.com/category/benches.html?type=hover-furniture-setteesbenches-benches";
        String actualUrl3= br.driver.getCurrentUrl();

        if(expectedUrl3.equalsIgnoreCase(actualUrl3)) {
            test3.log(Status.PASS, "Successfully navigated to the Benches");
        } else {
            test3.log(Status.FAIL, "Failed to navigate to the Benches");
        }

        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        // Click on "Material" category
        WebElement Material = br.driver.findElement(By.xpath("//*[@id=\"Material\"]/div/span"));
        highLighterMethod(br.driver, Material);
        Material.click();


        try {
            Thread.sleep(5000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        // Taking the count of Solid Wood benches
        String SolidWood = br.driver.findElement(By.xpath("//div[@class='color-secondary listing-count font-medium text-sm ng-star-inserted']/span[1]")).getText();
        int SW =Integer.parseInt(SolidWood.replaceAll("\\D", ""));
        String Solwood = "Solid Wood";
        System.out.println("Solid Wood benches are : " + SW);

        // Taking the count of Fabric benches
        String Fabric = br.driver.findElement(By.xpath("//div[@role='tabpanel']//div[2]/span[2]")).getText();
        int F =Integer.parseInt(Fabric.replaceAll("\\D", ""));
        String Fab = "Fabric";
        System.out.println("Fabric benches are : " + F);

        // Taking the count of Metal benches
        String Metal = br.driver.findElement(By.xpath("//div[@role='tabpanel']//div[3]/span[2]")).getText();
        int M =Integer.parseInt(Metal.replaceAll("\\D", ""));
        String Met = "Metal";
        System.out.println("Metal benches are : " + M);

        // Taking the count of Engineering Wood benches
        String EngineeringWood = br.driver.findElement(By.xpath("//div[@role='tabpanel']//div[4]/span[2]")).getText();
        int EW =Integer.parseInt(EngineeringWood.replaceAll("\\D", ""));
        String EngWood = "Engineering Wood";
        System.out.println("Engineering Wood benches are : " + EW);

        // Closing the Material Category
        WebElement MaterialClose = br.driver.findElement(By.xpath("//a[@class='drawer-close ng-star-inserted']"));
        MaterialClose.click();

        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        // Entering "Industrial Benches" in the search bar
        FileInputStream file = new FileInputStream("C:/Users/2282531/IdeaProjects/cogn/src/home/input.xlsx");
        Workbook Workbook = WorkbookFactory.create(file);
        Sheet Sheet= Workbook.getSheet("Sheet1");
        String name = Sheet.getRow(0).getCell(0).getStringCellValue();
        WebElement searchBox = br.driver.findElement(By.cssSelector("input[name='q']"));
        searchBox.sendKeys(name);

        highLighterMethod(br.driver, searchBox);

        // Click on search button
        WebElement sButton = br.driver.findElement(By.id("searchButton"));
        sButton.click();

//        try {
//            Thread.sleep(2000);
//        } catch (InterruptedException e) {
//            e.printStackTrace();
//        }

        ExtentTest test4 = extent.createTest("Test Case - 4", "Sample Description");
        test4.log(Status.INFO, "Navigating to Industrial Benches");
        String expectedUrl4 = "https://www.pepperfry.com/site_product/search?q=Industrial%20Benches&as=0&src=Industrial%20Benches&autoSuggest=1";
        String actualUrl4 = br.driver.getCurrentUrl();

        if(expectedUrl4.equalsIgnoreCase(actualUrl4)) {
            test4.log(Status.PASS, "Successfully navigated to Industrial Benches");
        } else {
            test4.log(Status.FAIL, "Failed to navigate to Industrial Benches");
        }

        File screenshot = ((TakesScreenshot) br.driver).getScreenshotAs(OutputType.FILE);
        try {
            FileUtils.copyFile(screenshot, new File("C:\\Users\\2282531\\IdeaProjects\\cogn\\src\\home\\Screenshot.png"));
            System.out.println("Screenshot taken successfully and saved to 'screenshot.png'");
        } catch (IOException e) {
            e.printStackTrace();
        }


//        Checking whether count of Industrial Benches is more than 1
        String  actualValString=br.driver.findElement(By.xpath("//div[@class='color-secondary listing-count font-medium text-sm ng-star-inserted']/span[2]")).getText();
        int icd=Integer.parseInt(actualValString.replaceAll("\\D", ""));
        if (icd > 1) {
            System.out.println("Industrial Benches are more than one, the count is - " + icd);
        } else {
            System.out.println("Industrial Benches are not more than one");
        }

        // Create a new Excel workbook
        Workbook workbook = new XSSFWorkbook();


                // Create a new sheet in the workbook
                Sheet sheet = workbook.createSheet("Output");

                String Ben = "Benches Categories";
                String count = "Count";

                // Execute your Selenium Java code and capture the output in a variable
//                String output = "Hello World!";



                // Write the output data to the sheet
        Row row = sheet.createRow(1);
//        Cell packageNameCell0 = row.createCell(0);
//        packageNameCell0.setCellValue(Ben);
        Cell packageNameCell = row.createCell(0);
        packageNameCell.setCellValue(Solwood);
        Cell packagePriceCell = row.createCell(1);
        packagePriceCell.setCellValue(Fab);
        Cell packagePriceCell1 = row.createCell(2);
        packagePriceCell1.setCellValue(Met);
        Cell packagePriceCell2 = row.createCell(3);
        packagePriceCell2.setCellValue(EngWood);

        Row row1 = sheet.createRow(2);
//        Cell packageNameCelli = row.createCell(0);
//        packageNameCelli.setCellValue(count);
        Cell packageNameCell3 = row1.createCell(0);
        packageNameCell3.setCellValue(SW);
        Cell packagePriceCell3 = row1.createCell(1);
        packagePriceCell3.setCellValue(F);
        Cell packagePriceCell4 = row1.createCell(2);
        packagePriceCell4.setCellValue(M);
        Cell packagePriceCell5 = row1.createCell(3);
        packagePriceCell5.setCellValue(EW);





                // Save the workbook to a file
                try (FileOutputStream outputStream = new FileOutputStream("C:\\Users\\2282531\\IdeaProjects\\cogn\\src\\home\\output.xlsx")) {
                    workbook.write(outputStream);
                } catch (Exception e) {
                    e.printStackTrace();
                } finally {
                    try {
                        workbook.close();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }


        // Closing the browser
        extent.flush();
        br.driver.close();
    }

    private static void highLighterMethod(WebDriver driver, WebElement element) {
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: 2px solid red;');", element);
    }
}
