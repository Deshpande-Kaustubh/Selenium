package home;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;

import java.util.Scanner;
public class Browser {
    public static WebDriver driver;
    public static Actions act;
    // WebDriver Setup Selection Method
    public static WebDriver setDriver() {
        Scanner scan = new Scanner(System.in);
        System.out.println("Which browser would you like to execute the script on? \r\n 1. Google Chrome \r\n 2. Edge ");
        int browserChoice = scan.nextInt();
        scan.close();

        if (browserChoice == 1) {
            driver = home.driverSetup.setChromeDriver();
        } else if (browserChoice == 2) {
            driver = home.driverSetup.setEdgeDriver();
        }
//        else if (browserChoice == 3) {
//            driver = home.driverSetup.setFirefoxDriver();
//        }
        else {
            System.out.println("Invalid data...");
        }
        act = new Actions(driver);
        return driver;

    }
}