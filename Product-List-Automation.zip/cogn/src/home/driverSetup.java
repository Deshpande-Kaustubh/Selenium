package home;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import home.Browser;
public class driverSetup {
    public static WebDriver setChromeDriver() {
        System.setProperty("webdriver.chrome.driver", "C:/Users/2282531/Downloads/chromedriver_win32/chromedriver.exe");
        home.Browser.driver = new ChromeDriver();
        home.Browser.driver.get("https://www.pepperfry.com/");
        return home.Browser.driver;
    }

    public static WebDriver setEdgeDriver() {
        System.setProperty("webdriver.edge.driver", "C:/Users/2282531/Downloads/edgedriver_win64/msedgedriver.exe");
        home.Browser.driver = new EdgeDriver();
        home.Browser.driver.get("https://www.pepperfry.com/");
        return home.Browser.driver;
    }

    // firefox Driver Setup Method
//    public static WebDriver setFirefoxDriver() {
//
//        System.setProperty("webdriver.gecko.driver","C:/Users/2282531/Downloads/geckodriver-v0.33.0-win32/geckodriver.exe");
//        home.Browser.driver = new FirefoxDriver();
//        home.Browser.driver.get("https://www.pepperfry.com/");
//        return home.Browser.driver;
//    }
}