package com.selenium.basic;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;

public class EdgeBrow {
    public static void main(String[] args) throws InterruptedException {
//        System.setProperty("webdriver.chrome.driver","C:/Users/2282531/Downloads/chromedriver_win32/chromedriver.exe");
//        WebDriver driver= new ChromeDriver();

        System.setProperty("webdriver.edge.driver", "C:/Users/2282531/Downloads/edgedriver_win64/msedgedriver.exe");
        WebDriver driver = new EdgeDriver();
        driver.manage().window().maximize();
        driver.get("https://www.pepperfry.com/");
        Thread.sleep(300);
//        driver.close();
    }
}
