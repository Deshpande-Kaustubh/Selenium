NEWS_AROUND_COGNIZANT
This Project is to Navigate to be.cognizant.com
Print Profile details and capture ScreenShot
Verify Around Cognizant
Print About Results,Newest, ExactMatchesOnly
Verify whether in the URL exactMatchesOnly is appended or not
The news displayed Should be appended in the ExcelSheet.
TO RUN THE PROJECT
you will need to have JAVA,Selenium, and TestNG installed on your System.
The outlook Userid and Password to Singin the outlook.
KEY AUTOMATION
This Project automates the following tasks:-
Navigating to the be.cognizant.com
Print Profile details and capture ScreenShot
Verify Around Cognizant
Print About Results,Newest, ExactMatchesOnly
Verify whether in the URL exactMatchesOnly is appended or not
The news displayed Should be appended in the ExcelSheet.
Multiple UI Validations.
TECHNOLOGIES
Java
Selenium
Maven
TestNG
Cucumber
KEY CONTRIBUTIONS
Spandan Ponde
Shreya Jawale
Aakash Damdar
Kaustubh Deshpande
Shubham Bagul