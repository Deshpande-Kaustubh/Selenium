package TestModules;

import java.time.Duration;
import java.util.List;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import UtilityClasses.DriverSetup;
import UtilityClasses.HighlightOptions;
import UtilityClasses.TakeScreenShots;

import java.io.FileOutputStream;
import java.io.IOException;
public class AboutCognizant  {
	
	public static WebDriver driver1 = DriverSetup.driver;
	
	HighlightOptions HO = new HighlightOptions();
    public JavascriptExecutor js = (JavascriptExecutor) driver1;
    public WebDriverWait wait = new WebDriverWait(driver1, Duration.ofSeconds(10));
    public List<WebElement> newsElements;
    
    // Globally locate WebElements
    public By contentScrollRegionBy = By.xpath("//div[@data-automation-id='contentScrollRegion']");
    public By aroundCognizantBy = By.xpath("//span[normalize-space()='Around Cognizant']");
    public By newsHeadlineBy = By.xpath("//div[@class='z_a_91bed31b']/div/a");

    public void aboutCTS() throws IOException {
        try {
            wait.until(ExpectedConditions.elementToBeClickable(contentScrollRegionBy));
            WebElement element = driver1.findElement(aroundCognizantBy);
            js.executeScript("arguments[0].scrollIntoView();", element);
            String actualString = "Around Cognizant";
            HO.flash(element, driver1);
            element.click();
            String expectedString = element.getText();
            assert expectedString.equalsIgnoreCase(actualString) : "Text does not match!";
            TakeScreenShots.Screenshoot("Around_Cognizant", driver1);
        } catch (Exception e) {
        	TakeScreenShots.takeScreenShotOnFailure("Fail_aboutCognizant", driver1);
        }
    }

    public List<WebElement> validationsOf4News() throws InterruptedException {
        try {
            newsElements = wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(newsHeadlineBy));
            TakeScreenShots.Screenshoot("News_Headlines", driver1);
            Workbook workbook = new XSSFWorkbook();
            Sheet sheet = workbook.createSheet("News Headlines");

            Row headerRow = sheet.createRow(0);
            Cell headlineCell = headerRow.createCell(0);
            headlineCell.setCellValue("Headline");
            Cell tooltipCell = headerRow.createCell(1);
            tooltipCell.setCellValue("Tooltip");

            int rowNum = 1;

            for (WebElement newsTitle : newsElements) {
                String headline = newsTitle.getText();
                String tooltip = newsTitle.getAttribute("aria-label");

                Row row = sheet.createRow(rowNum);

                Cell headlineCellData = row.createCell(0);
                headlineCellData.setCellValue(headline);

                Cell tooltipCellData = row.createCell(1);
                tooltipCellData.setCellValue(tooltip);

                if (headline.equals(tooltip)) {
                    System.out.println("Headline: " + headline + "\nTooltip: " + tooltip + "\n (Match)");
                } else {
                    System.out.println("Headline: " + headline + "\nTooltip: " + tooltip + "\n (Mismatch)");
                }

                rowNum++;
            }

            String filePath = "C:\\Users\\2282531\\IdeaProjects\\Around_Cognizant (4) (1) (1)\\Around_Cognizant\\ExcelFiles\\NewsHeadLines.xlsx";
            try {
                FileOutputStream outputStream = new FileOutputStream(filePath);
                workbook.write(outputStream);
            } catch (IOException e) {
                e.printStackTrace();
            } finally {
                try {
                    workbook.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }

            return newsElements;
        } catch (Exception e) {
            return null;
        }
    }
}
