package TestModules;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.time.Duration;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import UtilityClasses.DriverSetup;
import UtilityClasses.HighlightOptions;
import UtilityClasses.TakeScreenShots;

public class UserValidation  {
	
	public static WebDriver driver1 = DriverSetup.driver;
	
	HighlightOptions HO = new HighlightOptions();
	public By signInButtonLocator = By.xpath("//div[@id='O365_HeaderRightRegion']/div/button[@id='O365_MainLink_Me']");
	public By profileUserNameLocator = By.id("mectrl_currentAccount_primary");
	public By profileEmailLocator = By.id("mectrl_currentAccount_secondary");
	public String[] str = new String[2];
	public Workbook workbook;
	public Sheet sheet;
	public Row row;
	public Cell userNameCell;
	public Cell emailCell;

	public String[] validation() throws IOException {
		try {
			WebDriverWait wait = new WebDriverWait(driver1, Duration.ofSeconds(20));
			Thread.sleep(5000);
			wait.until(ExpectedConditions.elementToBeClickable(signInButtonLocator));
			WebElement signInButton = driver1.findElement(signInButtonLocator);
			HO.flash(signInButton, driver1);
			signInButton.click();
			//TakeScreenShots.Screenshoot("User_Validation", driver1);
			wait.until(ExpectedConditions.elementToBeClickable(profileUserNameLocator));
			WebElement profileUserName = driver1.findElement(profileUserNameLocator);
			HO.flash(profileUserName, driver1);
			String userName = profileUserName.getText();
			System.out.println("Username : " + userName);
			wait.until(ExpectedConditions.elementToBeClickable(profileEmailLocator));
			WebElement profileEmail = driver1.findElement(profileEmailLocator);
			HO.flash(profileEmail, driver1);
			String email = profileEmail.getText();
			System.out.println("Email : " + email);
			TakeScreenShots.Screenshoot("userValidation", driver1);
			
			
			str[0] = userName;
			str[1] = email;
			
			writeUserDetailsToExcel(userName, email);
			return str;
		} catch (Exception e) {
			TakeScreenShots.takeScreenShotOnFailure("Fail_to_userValidation", driver1);
			return null;
		}
	}

	public void writeUserDetailsToExcel(String userName, String email) {
		try {
			String filePath = "C:\\Users\\2282531\\IdeaProjects\\Around_Cognizant (4) (1) (1)\\Around_Cognizant\\ExcelFiles\\UserDetails.xlsx";

			// Check if the Excel file already exists
			if (new File(filePath).exists()) {
				workbook = WorkbookFactory.create(new FileInputStream(filePath));
				sheet = workbook.getSheetAt(0);
			} else {
				workbook = new XSSFWorkbook();
				sheet = workbook.createSheet("User Details");
				row = sheet.createRow(0);
				userNameCell = row.createCell(0);
				emailCell = row.createCell(1);
				userNameCell.setCellValue("Username");
				emailCell.setCellValue("Email");
			}

			int lastRowIndex = sheet.getLastRowNum();
			row = sheet.createRow(lastRowIndex + 1);
			userNameCell = row.createCell(0);
			emailCell = row.createCell(1);
			userNameCell.setCellValue(userName);
			emailCell.setCellValue(email);

			FileOutputStream outputStream = new FileOutputStream(filePath);
			workbook.write(outputStream);
			workbook.close();
			outputStream.close();

			System.out.println("User details have been written to the Excel file.");
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
