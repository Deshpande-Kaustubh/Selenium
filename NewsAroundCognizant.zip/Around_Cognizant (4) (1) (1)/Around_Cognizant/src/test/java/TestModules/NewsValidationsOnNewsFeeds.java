package TestModules;

import java.io.IOException;
import java.util.List;
import org.openqa.selenium.WebElement;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import java.io.FileOutputStream;
import java.util.ArrayList;

public class NewsValidationsOnNewsFeeds {
	
	  public void validateNewswithNewsFeed(List<WebElement> fourNewsTitle, List<WebElement> allNewsTitle)
	  {
		  
		  List<String> matchedTitles = new ArrayList<String>();
	        List<String> unmatchedTitles = new ArrayList<String>();

	        for (WebElement title : fourNewsTitle) {
	            String titleText = title.getText();
	            boolean found = false;
	            for (WebElement allTitle : allNewsTitle) {
	                if (titleText.equals(allTitle.getText())) {
	                    found = true;
	                    break;
	                }
	            }
	            if (found) {
	                matchedTitles.add(titleText);
	            } else {
	                unmatchedTitles.add(titleText);
	            }
	        }

	        writeTitlesToExcel(matchedTitles, "matched_titles.xlsx");
	        writeTitlesToExcel(unmatchedTitles, "unmatched_titles.xlsx");
	    }

	    public  void writeTitlesToExcel(List<String> titles, String fileName) {
	    	String filePath = "C:\\Users\\2282531\\IdeaProjects\\Around_Cognizant (4) (1) (1)\\Around_Cognizant\\ExcelFiles\\" + fileName;
	        Workbook workbook = new XSSFWorkbook();
	        Sheet sheet = workbook.createSheet("Titles");

	        for (int i = 0; i < titles.size(); i++) {
	            Row row = sheet.createRow(i);
	            Cell cell = row.createCell(0);
	            cell.setCellValue(titles.get(i));
	        }
	        try {
	            FileOutputStream outputStream = new FileOutputStream(filePath);
	            workbook.write(outputStream);
	            workbook.close();
	            outputStream.close();
	        } catch (IOException e) {
	        }
	    }
}
