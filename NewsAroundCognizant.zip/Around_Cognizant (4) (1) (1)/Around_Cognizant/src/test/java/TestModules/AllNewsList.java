package TestModules;

import java.io.FileWriter;
import java.io.IOException;
import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import UtilityClasses.DriverSetup;
import UtilityClasses.HighlightOptions;
import UtilityClasses.TakeScreenShots;

public class AllNewsList  {
	public static WebDriver driver1 = DriverSetup.driver;
	public JavascriptExecutor js = (JavascriptExecutor) driver1;
	public WebDriverWait wait = new WebDriverWait(driver1, Duration.ofSeconds(10));
	public WebElement sellAllElement;
	public List<WebElement> news;
	HighlightOptions HO = new HighlightOptions();

	public  void clickOnSeeAll() throws InterruptedException {
		try {
			sellAllElement = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[@title='/sites/Be.Cognizant/_layouts/15/news.aspx']")));
			js.executeScript("arguments[0].scrollIntoView();", sellAllElement);
			HO.flash(sellAllElement, driver1);
			sellAllElement.click();
			
		} catch (Exception e) {
			
		}
	}

	public List<WebElement> fetchNews() throws InterruptedException, IOException {
		try {
			wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.cssSelector("a[data-automation-id='newsItemTitle']")));
			news = driver1.findElements(By.cssSelector("a[data-automation-id='newsItemTitle']"));
			
			TakeScreenShots.Screenshoot("fetchNews", driver1);
			for (int i = 0; i < 4; i++) {
				Thread.sleep(4000);
				wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.cssSelector("a[data-automation-id='newsItemTitle']")));
				news = driver1.findElements(By.cssSelector("a[data-automation-id='newsItemTitle']"));
				fetchSingleNews(i);
			}

			return news;
		} catch (Exception e) {
			TakeScreenShots.takeScreenShotOnFailure("Fail_fetchNews", driver1);
			return null;
		}
	}

	public void fetchSingleNews(int index) throws InterruptedException, IOException {

		try {
			HO.flash(news.get(index), driver1);
			news.get(index).click();
			Thread.sleep(2000);
			List<WebElement> paragraphElements = driver1.findElements(By.tagName("section"));
			TakeScreenShots.Screenshoot("fetchSingleNews", driver1);
			StringBuilder contentBuilder = new StringBuilder();

			for (WebElement paragraph : paragraphElements) {
				String paragraphContent = paragraph.getText();
				String tooltip = paragraph.getAttribute("aria-label");
				contentBuilder.append(paragraphContent).append("\n");
				contentBuilder.append(tooltip).append("\n");
			}

			System.out.println(contentBuilder);

			try {
				String notePadFileName = ".//newsfiles//newzcontent" + (index + 1);
				FileWriter writer = new FileWriter(notePadFileName);
				writer.write(contentBuilder.toString());
				writer.close();
				System.out.println("Content written");
			} catch (IOException e) {
				e.printStackTrace();
			}

			driver1.navigate().back();
		} catch (Exception e) {
			TakeScreenShots.takeScreenShotOnFailure("Fail_to_fetchNews", driver1);
		}
	}
}
