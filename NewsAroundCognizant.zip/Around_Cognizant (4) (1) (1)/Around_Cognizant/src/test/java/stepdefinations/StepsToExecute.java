package stepdefinations;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.List;

import org.openqa.selenium.WebElement;

import TestModules.*;
import UtilityClasses.DriverSetup;

public class StepsToExecute {
	
	//Variables 	
	List<WebElement> fourNews;
	List<WebElement> allNews;
	
	//Object of TestModules class
	AboutCognizant aboutCognizant = new AboutCognizant();
	AllNewsList allNewsList = new AllNewsList();
	NewsValidationsOnNewsFeeds newsValidationsOnNewsFeeds = new NewsValidationsOnNewsFeeds();
	UserValidation  userValidation = new UserValidation();
		
	@Given("I am on the Cognizant homepage")
    public void navigateToCognizantHomepage() throws FileNotFoundException, InterruptedException, IOException {
        // Code to navigate to the Cognizant homepage
		System.out.println("Navigate to the page successfully.");	
    }

    @When("I perform user validation")
    public void performUserValidation() throws IOException {
        // Code to perform user validation
    	userValidation.validation();
    }


    @When("I click on Around Cognizant")
    public void clickOnAroundCognizant() throws IOException {
        // Code to click on the "Around Cognizant" link
    	aboutCognizant.aboutCTS();
    }

    @Then("I should validate the news headlines with tooltips and store it")
    public void validateNewsHeadlinesWithTooltips() throws InterruptedException {
        // Code to validate the news headlines with tooltips and store them
    	fourNews = aboutCognizant.validationsOf4News();
    }
    
    @When("I click on seeAll button.")
    public void seeAll() throws InterruptedException
    {
    	allNewsList.clickOnSeeAll();
    }
    
    @Then("I should fetch all the top 4 news on NewsFeed")
    public void FetchNews() throws InterruptedException, IOException
    {
    	allNews = allNewsList.fetchNews();
    }
    
    @Then("I should close all web Browsers.")
    public void closeBrowser() throws InterruptedException
    {
    	DriverSetup.closeBrowser();
    }
}
