package UtilityClasses;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.time.Duration;
import java.util.Properties;
import io.cucumber.java.Before;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class DriverSetup {

    public static WebDriver driver = null;
    public static HighlightOptions HO = new HighlightOptions();
    public static WebElement emailInput;
    public static WebElement nextButton;
    public static WebElement passwordInput;
    public static WebElement approveRequest;
    public static WebElement lightbox;
    public static WebElement approvalButton;
    public By id = By.id("i0116");

    @Before
    public static void setUp() throws InterruptedException, FileNotFoundException, IOException {
        OpenBrowser();
        signIn();
    }

    public static void OpenBrowser() throws InterruptedException, FileNotFoundException, IOException {
        // Fetching browser data from config.properties file...
        Properties props = new Properties();
        props.load(new FileInputStream("src/test/java/Config/Config.properties")); // Loading the properties
        String browser = props.getProperty("browser");
        try {

            if (browser.equalsIgnoreCase("chrome")) {
                // create object of web driver
                ChromeOptions co = new ChromeOptions();
                co.addArguments("start-maximized");
                co.addArguments("--disable-blink-features=AutomationControlled");
                co.addArguments("--disable-notifications"); // Disabling any notifications
                System.setProperty("webdriver.chrome.driver",
                        "C:\\Users\\2282531\\Downloads\\chromedriver_win32\\chromedriver.exe");

                driver = new ChromeDriver(co);
            } else if (browser.equalsIgnoreCase("edge")) {
                // create object of web driver
                EdgeOptions e = new EdgeOptions();
                e.addArguments("start-maximized");
                e.addArguments("--disable-blink-features=AutomationControlled");
                e.addArguments("--disable-notifications"); // Disabling any notifications

                driver = new EdgeDriver(e);
            } else if (browser.equalsIgnoreCase("Firefox")) {
                // create object of web driver
                FirefoxOptions fo = new FirefoxOptions();
                driver = new FirefoxDriver(fo);
            } else {
                throw new IllegalArgumentException("Invalid browser name");
            }
        } catch (Exception e) {
            System.out.println("We couldn't find the requested browser: opening Edge by default");

            EdgeOptions e1 = new EdgeOptions();
            driver = new EdgeDriver(e1);
        }
        // To maximize the browser.
        driver.manage().window().maximize();
    }

    public static void signIn() throws InterruptedException {

        try {
            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
            driver.get("https://cognizantonline.sharepoint.com/sites/Be.Cognizant/SitePages/Home.aspx");
//            wait.until(ExpectedConditions.elementToBeClickable(By.id("i0116")));
//
//            emailInput = driver.findElement(By.id("i0116"));
//            HO.flash(emailInput, driver);
//            emailInput.sendKeys("2266630@cognizant.com");
//
//            wait.until(ExpectedConditions.elementToBeClickable(By.id("idSIButton9")));
//
//            nextButton = driver.findElement(By.id("idSIButton9"));
//            HO.flash(nextButton, driver);
//            nextButton.click();
//
//            wait.until(ExpectedConditions.elementToBeClickable(By.id("i0118")));
//            passwordInput = driver.findElement(By.id("i0118"));
//            HO.flash(passwordInput, driver);
//            passwordInput.sendKeys("Ranurinku@2710");
//
//            wait.until(ExpectedConditions.elementToBeClickable(By.id("idSIButton9")));
//            nextButton = driver.findElement(By.id("idSIButton9"));
//            HO.flash(nextButton, driver);
//            nextButton.click();

            wait.until(ExpectedConditions
                    .elementToBeClickable(By.xpath("//div[text()='Approve a request on my Microsoft Authenticator app']")));

            approveRequest = driver
                    .findElement(By.xpath("//div[text()='Approve a request on my Microsoft Authenticator app']"));
            HO.flash(approveRequest, driver);
            approveRequest.click();
            Thread.sleep(5000);
//            wait.until(ExpectedConditions.elementToBeClickable(By.id("idSIButton9")));
//            approvalButton = driver.findElement(By.id("idSIButton9"));
//            HO.flash(approvalButton, driver);
//            approvalButton.click();

        } catch (Exception e) {
        }
    }
    
    
    public static void closeBrowser() throws InterruptedException // method to close the browser
    {
        driver.quit(); // To close the browser
    }
}
