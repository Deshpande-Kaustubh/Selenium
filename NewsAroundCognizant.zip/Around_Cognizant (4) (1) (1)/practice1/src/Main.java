public class Main {
    public static void main(String[] args) {
        String a = "abcde";
        String b = ""
        System.out.println("Hello world!");
    }
}